package com.chattracker

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Store {
    private const val MAX = 200
    private fun sp(c: Context) = c.getSharedPreferences("tracker", Context.MODE_PRIVATE)

    fun filterPkg(c: Context): String = sp(c).getString("pkg", "") ?: ""
    fun setFilterPkg(c: Context, v: String) = sp(c).edit().putString("pkg", v.trim()).apply()

    fun checkMode(c: Context): Boolean = sp(c).getBoolean("check", true)
    fun setCheckMode(c: Context, v: Boolean) = sp(c).edit().putBoolean("check", v).apply()

    fun autoCopy(c: Context): Boolean = sp(c).getBoolean("autocopy", true)
    fun setAutoCopy(c: Context, v: Boolean) = sp(c).edit().putBoolean("autocopy", v).apply()

    fun debug(c: Context): String = sp(c).getString("debug", "") ?: ""
    fun setDebug(c: Context, s: String) = sp(c).edit().putString("debug", s).apply()

    @Synchronized
    fun addLog(c: Context, text: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val list = getLog(c).toMutableList()
        list.add(0, "$t  $text")
        while (list.size > MAX) list.removeAt(list.size - 1)
        sp(c).edit().putString("log", list.joinToString("\n")).apply()
    }

    fun getLog(c: Context): List<String> {
        val s = sp(c).getString("log", "") ?: ""
        return if (s.isEmpty()) emptyList() else s.split("\n")
    }

    fun clearLog(c: Context) = sp(c).edit().remove("log").apply()
}
