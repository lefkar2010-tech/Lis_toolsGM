package com.chattracker

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import java.util.Date
import java.util.Locale

data class Rule(val shortCommand: String, val outputTemplate: String) {
    fun requiresId(): Boolean = outputTemplate.contains("{id}")
    fun acceptsText(): Boolean = outputTemplate.contains("{text}")

    fun expand(id: String = "", text: String = ""): String =
        outputTemplate.replace("{id}", id)
            .replace("{text}", text.trim())
            .replace(Regex("\\s+"), " ")
            .trim()

    fun preview(): String {
        var sample = shortCommand
        if (requiresId()) sample += " 22"
        if (acceptsText()) sample += " привет"
        val res = expand(if (requiresId()) "22" else "", if (acceptsText()) "привет" else "")
        return "$sample → $res"
    }
}

data class Report(
    val uid: Long,
    val time: String,
    val nick: String,
    val pid: String,
    val msg: String,
    val queue: Int
)

object Store {
    private const val MAX_LOG = 200
    private const val MAX_REPORTS = 200

    private val REPORT_CMDS = listOf("/ans", "/pm", "/arep")
    private val PUNISH_CMDS = listOf("/jail", "/warn", "/mute", "/ban")

    fun prefs(c: Context): SharedPreferences =
        c.getSharedPreferences("tracker", Context.MODE_PRIVATE)

    private fun sp(c: Context) = prefs(c)

    private fun nowTime(): String = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())

    // ---------- настройки ----------
    fun filterPkg(c: Context): String = sp(c).getString("pkg", "") ?: ""
    fun setFilterPkg(c: Context, v: String) = sp(c).edit().putString("pkg", v.trim()).apply()

    fun checkMode(c: Context): Boolean = sp(c).getBoolean("check", true)
    fun setCheckMode(c: Context, v: Boolean) = sp(c).edit().putBoolean("check", v).apply()

    fun autoCopy(c: Context): Boolean = sp(c).getBoolean("autocopy", true)
    fun setAutoCopy(c: Context, v: Boolean) = sp(c).edit().putBoolean("autocopy", v).apply()

    fun hotPkgs(c: Context): Set<String> =
        (sp(c).getString("hot", "") ?: "").split(",").filter { it.isNotEmpty() }.toSet()

    fun addHotPkg(c: Context, p: String) {
        val s = hotPkgs(c).toMutableSet()
        s.add(p)
        sp(c).edit().putString("hot", s.joinToString(",")).apply()
    }

    fun clearHotPkgs(c: Context) = sp(c).edit().remove("hot").apply()

    fun overlayOn(c: Context): Boolean = sp(c).getBoolean("overlay", true)
    fun setOverlayOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("overlay", v).apply()


    fun requestTestForm(c: Context) =
        sp(c).edit().putString("test_form", System.currentTimeMillis().toString()).apply()

    fun debug(c: Context): String = sp(c).getString("debug", "") ?: ""
    fun setDebug(c: Context, s: String) = sp(c).edit().putString("debug", s).apply()

    // ---------- журнал ----------
    @Synchronized
    fun addLog(c: Context, text: String) {
        val list = getLog(c).toMutableList()
        list.add(0, "${nowTime()}  $text")
        while (list.size > MAX_LOG) list.removeAt(list.size - 1)
        sp(c).edit().putString("log", list.joinToString("\n")).apply()
    }

    fun getLog(c: Context): List<String> {
        val s = sp(c).getString("log", "") ?: ""
        return if (s.isEmpty()) emptyList() else s.split("\n")
    }

    fun clearLog(c: Context) = sp(c).edit().remove("log").apply()

    // ---------- правила автозамены ----------
    private fun defaultRules(): List<Rule> = listOf(
        Rule("/dm", "/jail {id} 60 DM"),
        Rule("/osk", "/mute {id} 30 2.1 ОП"),
        Rule("/warn", "/warn {id} 1.1 НРП"),
        Rule("/ans", "/ans {text}"),
        Rule("/pm", "/pm {id} {text}"),
        Rule("/arep", "/arep {text}"),
        Rule("/a", "/msg {text}")
    )

    private fun parseRules(a: JSONArray): List<Rule> {
        val out = ArrayList<Rule>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val s = o.optString("shortCommand", "").trim()
            val t = o.optString("outputTemplate", "").trim()
            if (s.isNotEmpty() && t.isNotEmpty()) out.add(Rule(s, t))
        }
        return out
    }

    private fun rulesToJson(rules: List<Rule>): JSONArray {
        val a = JSONArray()
        for (r in rules) {
            val o = JSONObject()
            o.put("shortCommand", r.shortCommand)
            o.put("outputTemplate", r.outputTemplate)
            a.put(o)
        }
        return a
    }

    fun loadRules(c: Context): List<Rule> {
        val raw = sp(c).getString("rules", null) ?: return defaultRules()
        return try {
            parseRules(JSONArray(raw))
        } catch (e: Exception) {
            defaultRules()
        }
    }

    @Synchronized
    fun saveRules(c: Context, rules: List<Rule>) {
        sp(c).edit().putString("rules", rulesToJson(rules).toString()).apply()
    }

    fun exportRulesJson(c: Context): String {
        val o = JSONObject()
        o.put("version", 1)
        o.put("exportedAt", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()))
        o.put("rules", rulesToJson(loadRules(c)))
        return o.toString(2)
    }

    // Принимает массив правил или объект {"rules":[...]}; одинаковые сокращения заменяются
    @Synchronized
    fun importRulesJson(c: Context, raw: String): Int {
        val t = raw.trim()
        val arr = if (t.startsWith("[")) JSONArray(t) else JSONObject(t).getJSONArray("rules")
        val incoming = parseRules(arr)
        if (incoming.isEmpty()) return 0
        val cur = loadRules(c).toMutableList()
        for (r in incoming) {
            val i = cur.indexOfFirst { it.shortCommand.equals(r.shortCommand, ignoreCase = true) }
            if (i >= 0) cur[i] = r else cur.add(r)
        }
        saveRules(c, cur)
        return incoming.size
    }

    // ---------- счётчики команд ----------
    private fun loadStats(c: Context): JSONObject =
        try {
            JSONObject(sp(c).getString("stats", "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }

    @Synchronized
    fun recordCommand(c: Context, expanded: String) {
        val parts = expanded.trim().split(Regex("\\s+"))
        val cmd = parts.firstOrNull()?.lowercase(Locale.ROOT) ?: return

        if (cmd in REPORT_CMDS || cmd in PUNISH_CMDS) {
            val st = loadStats(c)
            val day = LocalDate.now().toString()
            val d = st.optJSONObject(day) ?: JSONObject()
            d.put(cmd, d.optInt(cmd, 0) + 1)
            st.put(day, d)
            val limit = LocalDate.now().minusDays(60).toString()
            val old = st.keys().asSequence().filter { it < limit }.toList()
            for (k in old) st.remove(k)
            sp(c).edit().putString("stats", st.toString()).apply()
        }
    }

    fun statsSummary(c: Context): String {
        val st = loadStats(c)
        val today = LocalDate.now()
        val weekStart = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val prevStart = weekStart.minusDays(7)
        val prevEnd = weekStart.minusDays(1)

        fun count(from: LocalDate, to: LocalDate, cmds: List<String>): Int {
            var n = 0
            var d = from
            while (!d.isAfter(to)) {
                val o = st.optJSONObject(d.toString())
                if (o != null) {
                    for (k in cmds) n += o.optInt(k, 0)
                }
                d = d.plusDays(1)
            }
            return n
        }

        fun block(title: String, cmds: List<String>): String =
            title + " (" + cmds.joinToString(", ") + ")\n" +
                "Сегодня: " + count(today, today, cmds) +
                " | Неделя: " + count(weekStart, today, cmds) +
                " | Прошлая неделя: " + count(prevStart, prevEnd, cmds)

        return block("Репорты", REPORT_CMDS) + "\n\n" + block("Наказания", PUNISH_CMDS)
    }

    // ---------- список репортов ----------
    fun getReports(c: Context): List<Report> {
        val raw = sp(c).getString("reports", "[]") ?: "[]"
        return try {
            val a = JSONArray(raw)
            val out = ArrayList<Report>()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                if (o.optBoolean("done")) continue
                out.add(
                    Report(
                        o.getLong("uid"), o.optString("time"), o.optString("nick"),
                        o.optString("pid"), o.optString("msg"), o.optInt("queue")
                    )
                )
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveReports(c: Context, list: List<Report>) {
        val a = JSONArray()
        for (r in list) {
            val o = JSONObject()
            o.put("uid", r.uid)
            o.put("time", r.time)
            o.put("nick", r.nick)
            o.put("pid", r.pid)
            o.put("msg", r.msg)
            o.put("queue", r.queue)
            a.put(o)
        }
        sp(c).edit().putString("reports", a.toString()).apply()
    }

    @Synchronized
    fun addReport(c: Context, time: String, nick: String, pid: String, msg: String, queue: Int) {
        val t = if (time.isEmpty()) nowTime() else time
        val list = getReports(c).toMutableList()
        if (time.isNotEmpty() && list.any {
                it.time == t && it.nick == nick && it.pid == pid && it.msg == msg && it.queue == queue
            }
        ) return
        val now = System.currentTimeMillis()
        val uid = if (list.isNotEmpty() && list[0].uid >= now) list[0].uid + 1 else now
        list.add(0, Report(uid, t, nick, pid, msg, queue))
        while (list.size > MAX_REPORTS) list.removeAt(list.size - 1)
        saveReports(c, list)
    }

    @Synchronized
    fun deleteReport(c: Context, uid: Long) {
        saveReports(c, getReports(c).filter { it.uid != uid })
    }

    @Synchronized
    fun clearReports(c: Context) {
        saveReports(c, emptyList())
    }
}
