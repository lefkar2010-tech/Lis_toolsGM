package com.chattracker

import android.accessibilityservice.AccessibilityService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.app.NotificationCompat
import java.util.concurrent.atomic.AtomicBoolean

object Clip {
    fun copy(c: Context, text: String) {
        val cm = c.getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("cmd", text))
    }
}

class CopyReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val t = i.getStringExtra("text") ?: return
        Clip.copy(c, t)
    }
}

object Notifier {
    private const val CH = "tracker_alerts"
    private var nextId = 100

    fun ensureChannel(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null) {
            val ch = NotificationChannel(CH, "Оповещения чата", NotificationManager.IMPORTANCE_HIGH)
            ch.enableVibration(true)
            ch.vibrationPattern = longArrayOf(0, 400, 200, 400)
            nm.createNotificationChannel(ch)
        }
    }

    fun show(c: Context, title: String, text: String, copy: String? = null) {
        ensureChannel(c)
        val id = nextId++
        val pi = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(c, CH)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi)
        if (copy != null) {
            val ri = Intent(c, CopyReceiver::class.java).putExtra("text", copy)
            val rp = PendingIntent.getBroadcast(
                c, id, ri, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            b.addAction(0, "Копировать", rp)
        }
        c.getSystemService(NotificationManager::class.java).notify(id, b.build())
    }
}

class TrackerService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var overlay: OverlayManager? = null
    private var suppressNext = false
    private val unsuppress = Runnable { suppressNext = false }

    // сканирование идёт в отдельном потоке, как у GTAndroid: 0.4 с в игре, 3 с в остальных приложениях
    private var scanThread: HandlerThread? = null
    private var scanHandler: Handler? = null
    private val inFlight = AtomicBoolean(false)
    @Volatile private var running = false
    @Volatile private var lastScan = 0L
    @Volatile private var hotNow = false

    // состояние сканирования, трогаем только из потока сканирования
    private val seen = LinkedHashSet<String>()
    private var seeded = false
    private var lastPkg = ""
    private val pkgInfo = LinkedHashMap<String, String>()

    private val scanOnce = Runnable { runScan() }
    private val pollTick = object : Runnable {
        override fun run() {
            if (!running) return
            if (inFlight.compareAndSet(false, true)) runScan()
            scanHandler?.postDelayed(this, if (hotNow) 400L else 3000L)
        }
    }

    override fun onServiceConnected() {
        Notifier.ensureChannel(this)
        Store.setDebug(this, "Служба запущена, жду события…")
        overlay = OverlayManager(this)
        overlay?.start()
        updateOverlayVisibility()

        if (scanThread == null) {
            val t = HandlerThread("TrackerScan")
            t.start()
            scanThread = t
            scanHandler = Handler(t.looper)
        }
        running = true
        scanHandler?.post(pollTick)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        scanHandler?.removeCallbacksAndMessages(null)
        scanThread?.quitSafely()
        scanThread = null
        scanHandler = null
        overlay?.stop()
        overlay = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return

        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) updateOverlayVisibility()

        // Автозамена: срабатывает в любом приложении, где есть поле ввода
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            if (handleExpand(e)) return
        }

        // Чат-трекер: события от игры только подгоняют ближайший опрос
        val evPkg = e.packageName?.toString() ?: return
        if (evPkg == packageName) return
        if (!isHot(evPkg)) return
        requestScan()
    }

    private fun isHot(pkg: String): Boolean {
        val filter = Store.filterPkg(this)
        if (filter.isNotEmpty()) return pkg == filter
        return Store.hotPkgs(this).contains(pkg)
    }

    // ---------- оверлей ----------
    // Кружок показываем только в игре (если она известна), в самом приложении скрываем
    fun updateOverlayVisibility() {
        val ov = overlay ?: return
        val filter = Store.filterPkg(this)
        val pkg = rootInActiveWindow?.packageName?.toString() ?: return
        val hot = Store.hotPkgs(this)
        val fg = when {
            pkg == packageName -> false
            filter.isNotEmpty() -> pkg == filter
            hot.isNotEmpty() -> hot.contains(pkg)
            else -> true
        }
        ov.setGameForeground(fg)
    }

    // Вставляет текст в сфокусированное поле ввода игры (отправляет пользователь сам)
    fun insertIntoChat(text: String): Boolean {
        val node = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        if (!node.isEditable) return false
        suppressNext = true
        val setArgs = Bundle()
        setArgs.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, setArgs)
        val selArgs = Bundle()
        selArgs.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, text.length)
        selArgs.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, text.length)
        node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, selArgs)
        handler.postDelayed(unsuppress, 160)
        return ok
    }

    // ---------- автозамена ----------
    // true, если событие пришло из редактируемого поля (дальше его обрабатывать не нужно)
    private fun handleExpand(e: AccessibilityEvent): Boolean {
        var node: AccessibilityNodeInfo? = e.source
        if (node == null) node = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (node == null) return false
        if (!node.isEditable) return false
        if (suppressNext || node.isPassword) return true

        val text = node.text?.toString() ?: return true
        if (text.isBlank()) return true
        val sep = when {
            text.endsWith(" ") -> " "
            text.endsWith("\n") -> "\n"
            else -> return true
        }

        val repl = Expander.buildReplacement(this, text) ?: return true
        val newText = repl + sep

        suppressNext = true
        val setArgs = Bundle()
        setArgs.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, newText)
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, setArgs)

        val selArgs = Bundle()
        selArgs.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, newText.length)
        selArgs.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, newText.length)
        node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, selArgs)

        handler.postDelayed(unsuppress, 160)
        return true
    }

    // ---------- чат-трекер ----------
    private fun requestScan() {
        if (!running) return
        if (SystemClock.uptimeMillis() - lastScan < 250) return
        if (inFlight.compareAndSet(false, true)) scanHandler?.post(scanOnce)
    }

    private fun runScan() {
        try {
            doScan()
        } catch (e: Exception) {
            Store.setDebug(this, "Ошибка сканирования: ${e.message}")
        } finally {
            inFlight.set(false)
        }
    }

    private fun doScan() {
        lastScan = SystemClock.uptimeMillis()
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (pkg == packageName) {
            hotNow = false
            return
        }
        val filter = Store.filterPkg(this)
        if (filter.isNotEmpty() && pkg != filter) {
            hotNow = false
            return
        }
        hotNow = isHot(pkg)

        if (pkg != lastPkg) {
            lastPkg = pkg
            seen.clear()
            seeded = false
        }

        val raw = ArrayList<String>()
        collect(root, raw, 0)
        val lines = Parser.mergeContinuations(raw)

        // нашли строки чата: запоминаем приложение как игру, дальше опрос идёт чаще
        if (!hotNow && filter.isEmpty() && lines.any { Parser.looksLikeChat(it) }) {
            Store.addHotPkg(this, pkg)
            hotNow = true
            Store.addLog(this, "Игра найдена: $pkg (чат читается)")
            handler.post { updateOverlayVisibility() }
        }

        val fresh = lines.filter { seen.add(it) }
        while (seen.size > 600) {
            val iter = seen.iterator()
            iter.next()
            iter.remove()
        }

        if (Store.checkMode(this)) {
            pkgInfo.remove(pkg)
            pkgInfo[pkg] = "строк ${lines.size}, новых ${fresh.size}"
            while (pkgInfo.size > 5) pkgInfo.remove(pkgInfo.keys.first())
            val keyLines = lines.filter {
                it.contains("репорта") || it.contains("Grnd_Bot") || it.contains("<ADM>")
            }.takeLast(4)
            val hot = if (filter.isNotEmpty()) setOf(filter) else Store.hotPkgs(this)
            val sb = StringBuilder()
            sb.append("Игра: ")
            sb.append(if (hot.isEmpty()) "не найдена (зайди в чат игры и подожди)" else hot.joinToString(", "))
            sb.append("\n\nПриложения (последние сверху):")
            for (e in pkgInfo.entries.toList().asReversed()) {
                sb.append("\n• ").append(e.key).append(" — ").append(e.value)
            }
            sb.append("\n\n")
            if (keyLines.isEmpty()) {
                sb.append("Строк со словами «репорта», «Grnd_Bot», «<ADM>» на экране нет.")
            } else {
                sb.append("Нужные строки:")
                for (k in keyLines) sb.append("\n• ").append(k.take(110))
            }
            Store.setDebug(this, sb.toString())
        }

        // Первое сканирование окна только запоминает видимую историю, без уведомлений
        if (!seeded) {
            seeded = true
            return
        }

        val events = ArrayList<Any>()
        var hitCount = 0
        for (l in fresh) {
            val a = Parser.answerOf(l)
            if (a != null) {
                events.add(a)
                continue
            }
            val h = Parser.parse(l)
            if (h != null) {
                events.add(h)
                hitCount++
            }
        }
        if (events.isEmpty()) return
        if (hitCount > 8) {
            Store.addLog(this, "Пропущено $hitCount старых строк (загрузка истории чата)")
            return
        }
        handler.post { deliver(events) }
    }

    // Выдача результатов в основном потоке: список, буфер, окно формы, уведомление, журнал
    private fun deliver(events: List<Any>) {
        for (ev in events) {
            if (ev is Answer) {
                handleAnswer(ev)
                continue
            }
            val h = ev as? Hit ?: continue
            if (h.kind == "form" && h.copy != null) overlay?.showForm(h.nick, h.copy)
            if (h.kind == "report") {
                Store.addReport(this, h.time, h.nick, h.pid, h.msg, h.queue)
            }
            if (h.copy != null && Store.autoCopy(this)) Clip.copy(this, h.copy)
            Notifier.show(this, h.title, h.text, h.copy)
            Store.addLog(this, "${h.title} — ${h.text}")
        }
    }

    // Ответ на репорт: репорт этого игрока убирается из списка.
    // Если задан «Мой ник», считаются только мои ответы, иначе ответы любого админа, кроме Grnd_Bot.
    private fun handleAnswer(a: Answer) {
        val mine = Store.myNick(this)
        val counts = if (mine.isNotEmpty()) {
            a.admin.equals(mine, ignoreCase = true)
        } else {
            !a.admin.equals("Grnd_Bot", ignoreCase = true)
        }
        if (!counts) return
        val n = Store.removeReportsByPlayer(this, a.pid)
        if (n > 0) Store.addLog(this, "Репорт убран: ID ${a.pid} (ответил ${a.admin})")
    }

    // Читаем и text, и contentDescription, как GTAndroid
    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (n == null || depth > 40 || out.size > 4000) return
        val t = n.text?.toString()
        if (t != null) {
            for (part in t.split('\n')) if (part.isNotBlank()) out.add(part.trim())
        }
        val cd = n.contentDescription?.toString()
        if (cd != null && cd != t) {
            for (part in cd.split('\n')) if (part.isNotBlank()) out.add(part.trim())
        }
        for (i in 0 until n.childCount) {
            val c = n.getChild(i)
            collect(c, out, depth + 1)
            c?.recycle()
        }
    }
}
