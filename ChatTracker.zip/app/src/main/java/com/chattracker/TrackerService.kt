package com.chattracker

import android.accessibilityservice.AccessibilityService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.app.NotificationCompat

object Clip {
    fun copy(c: Context, text: String) {
        val cm = c.getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("cmd", text))
    }
}

class CopyReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val t = i.getStringExtra("text") ?: return
        Clip.copy(c, t)
    }
}

object Notifier {
    private const val CH = "tracker_alerts"
    private var nextId = 100

    fun ensureChannel(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null) {
            val ch = NotificationChannel(CH, "Оповещения чата", NotificationManager.IMPORTANCE_HIGH)
            ch.enableVibration(true)
            ch.vibrationPattern = longArrayOf(0, 400, 200, 400)
            nm.createNotificationChannel(ch)
        }
    }

    fun show(c: Context, title: String, text: String, copy: String? = null) {
        ensureChannel(c)
        val id = nextId++
        val pi = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(c, CH)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi)
        if (copy != null) {
            val ri = Intent(c, CopyReceiver::class.java).putExtra("text", copy)
            val rp = PendingIntent.getBroadcast(
                c, id, ri, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            b.addAction(0, "Копировать", rp)
        }
        c.getSystemService(NotificationManager::class.java).notify(id, b.build())
    }
}

class TrackerService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val seen = LinkedHashSet<String>()
    private var seeded = false
    private var lastScan = 0L
    private var scanPending = false
    private var lastPkg = ""
    private var suppressNext = false

    private val scanRunnable = Runnable {
        scanPending = false
        doScan()
    }
    private val unsuppress = Runnable { suppressNext = false }

    override fun onServiceConnected() {
        Notifier.ensureChannel(this)
        seen.clear()
        seeded = false
        Store.setDebug(this, "Служба запущена, жду события…")
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return

        // Автозамена: срабатывает в любом приложении, где есть поле ввода
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            if (handleExpand(e)) return
        }

        // Чат-трекер
        val evPkg = e.packageName?.toString() ?: return
        if (evPkg == packageName) return
        val filter = Store.filterPkg(this)
        if (filter.isNotEmpty() && evPkg != filter) return
        requestScan()
    }

    // ---------- автозамена ----------
    // true, если событие пришло из редактируемого поля (дальше его обрабатывать не нужно)
    private fun handleExpand(e: AccessibilityEvent): Boolean {
        var node: AccessibilityNodeInfo? = e.source
        if (node == null) node = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (node == null) return false
        if (!node.isEditable) return false
        if (suppressNext || node.isPassword) return true

        val text = node.text?.toString() ?: return true
        if (text.isBlank()) return true
        val sep = when {
            text.endsWith(" ") -> " "
            text.endsWith("\n") -> "\n"
            else -> return true
        }

        val repl = Expander.buildReplacement(this, text) ?: return true
        val newText = repl + sep

        suppressNext = true
        val setArgs = Bundle()
        setArgs.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, newText)
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, setArgs)

        val selArgs = Bundle()
        selArgs.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, newText.length)
        selArgs.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, newText.length)
        node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, selArgs)

        handler.postDelayed(unsuppress, 160)
        return true
    }

    // ---------- чат-трекер ----------
    private fun requestScan() {
        val now = SystemClock.uptimeMillis()
        if (now - lastScan >= 300) {
            doScan()
        } else if (!scanPending) {
            scanPending = true
            handler.postDelayed(scanRunnable, 300)
        }
    }

    private fun doScan() {
        lastScan = SystemClock.uptimeMillis()
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (pkg == packageName) return
        val filter = Store.filterPkg(this)
        if (filter.isNotEmpty() && pkg != filter) return

        if (pkg != lastPkg) {
            lastPkg = pkg
            seen.clear()
            seeded = false
        }

        val lines = ArrayList<String>()
        collect(root, lines, 0)

        val fresh = lines.filter { seen.add(it) }
        while (seen.size > 600) {
            val iter = seen.iterator()
            iter.next()
            iter.remove()
        }

        if (Store.checkMode(this)) {
            val sample = fresh.takeLast(5).joinToString("\n") { "• " + it.take(90) }
            Store.setDebug(
                this,
                "Приложение: $pkg\nСтрок на экране: ${lines.size}, новых: ${fresh.size}" +
                    if (sample.isNotEmpty()) "\n$sample" else ""
            )
        }

        // Первое сканирование окна только запоминает видимую историю, без уведомлений
        if (!seeded) {
            seeded = true
            return
        }

        val hits = fresh.mapNotNull { l -> Parser.parse(l) }
        if (hits.size > 8) {
            Store.addLog(this, "Пропущено ${hits.size} старых строк (загрузка истории чата)")
            return
        }
        for (h in hits) {
            if (h.kind == "report") {
                Store.addReport(this, h.time, h.nick, h.pid, h.msg, h.queue)
            }
            if (h.copy != null && Store.autoCopy(this)) Clip.copy(this, h.copy)
            Notifier.show(this, h.title, h.text, h.copy)
            Store.addLog(this, "${h.title} — ${h.text}")
        }
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (n == null || depth > 40 || out.size > 3000) return
        n.text?.toString()?.split('\n')?.forEach { if (it.isNotBlank()) out.add(it.trim()) }
        for (i in 0 until n.childCount) collect(n.getChild(i), out, depth + 1)
    }
}
