package com.chattracker

import android.accessibilityservice.AccessibilityService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import androidx.core.app.NotificationCompat
import java.util.concurrent.atomic.AtomicBoolean

object Notifier {
    private const val CH = "tracker_alerts"
    private var nextId = 100

    fun ensureChannel(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null) {
            val ch = NotificationChannel(CH, "Оповещения чата", NotificationManager.IMPORTANCE_HIGH)
            ch.enableVibration(true)
            ch.vibrationPattern = longArrayOf(0, 400, 200, 400)
            nm.createNotificationChannel(ch)
        }
    }

    fun show(c: Context, title: String, text: String) {
        ensureChannel(c)
        val id = nextId++
        val pi = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(c, CH)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi)
        c.getSystemService(NotificationManager::class.java).notify(id, b.build())
    }
}

class TrackerService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var overlay: OverlayManager? = null
    @Volatile private var suppressNext = false
    private val unsuppress = Runnable { suppressNext = false }

    // сканирование идёт в отдельном потоке, как у GTAndroid: 0.4 с в игре, 3 с в остальных приложениях
    private var scanThread: HandlerThread? = null
    private var scanHandler: Handler? = null
    private val inFlight = AtomicBoolean(false)
    @Volatile private var running = false
    @Volatile private var lastScan = 0L
    @Volatile private var hotNow = false

    // состояние сканирования, трогаем только из потока сканирования
    private val seen = LinkedHashSet<String>()
    private var seeded = false
    private var lastPkg = ""
    private val pkgInfo = LinkedHashMap<String, String>()

    private val scanOnce = Runnable { runScan() }
    private val pollTick = object : Runnable {
        override fun run() {
            if (!running) return
            if (inFlight.compareAndSet(false, true)) runScan()
            scanHandler?.postDelayed(this, if (hotNow) 400L else 3000L)
        }
    }

    override fun onServiceConnected() {
        Notifier.ensureChannel(this)
        Store.setDebug(this, "Служба запущена, жду события…")
        overlay = OverlayManager(this)
        overlay?.start()

        if (scanThread == null) {
            val t = HandlerThread("TrackerScan")
            t.start()
            scanThread = t
            scanHandler = Handler(t.looper)
        }
        running = true
        scanHandler?.post(pollTick)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        scanHandler?.removeCallbacksAndMessages(null)
        scanThread?.quitSafely()
        scanThread = null
        scanHandler = null
        overlay?.stop()
        overlay = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return

        // Автозамена: срабатывает в любом приложении, где есть поле ввода
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            if (handleExpand(e)) return
        }

        // Чат-трекер: события от игры только подгоняют ближайший опрос
        val evPkg = e.packageName?.toString() ?: return
        if (evPkg == packageName) return
        if (!isHot(evPkg)) return
        requestScan()
    }

    private fun isHot(pkg: String): Boolean {
        val filter = Store.filterPkg(this)
        if (filter.isNotEmpty()) return pkg == filter
        return Store.hotPkgs(this).contains(pkg)
    }

    // ---------- отправка в чат игры ----------
    // Находим поле ввода чата, фокусируем его и записываем команду с переводом строки: это и есть отправка
    fun sendChat(text: String, done: (Boolean) -> Unit) {
        val sh = scanHandler
        if (sh == null) {
            done(false)
            return
        }
        sh.post {
            val ok = try {
                doSend(text)
            } catch (e: Exception) {
                false
            }
            handler.post { done(ok) }
        }
    }

    private fun doSend(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() == packageName) return false
        val node = findEditable(root, true, 0) ?: findEditable(root, false, 0) ?: return false
        suppressNext = true
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        try {
            Thread.sleep(60)
        } catch (e: InterruptedException) {
        }
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text + "\n")
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        handler.postDelayed(unsuppress, 600)
        return ok
    }

    private fun findEditable(n: AccessibilityNodeInfo?, focusedOnly: Boolean, depth: Int): AccessibilityNodeInfo? {
        if (n == null || depth > 40) return null
        if (n.isEditable && n.isEnabled && (!focusedOnly || n.isFocused)) return n
        for (i in 0 until n.childCount) {
            val r = findEditable(n.getChild(i), focusedOnly, depth + 1)
            if (r != null) return r
        }
        return null
    }

    // ---------- автозамена ----------
    // true, если событие пришло из редактируемого поля (дальше его обрабатывать не нужно)
    private fun handleExpand(e: AccessibilityEvent): Boolean {
        var node: AccessibilityNodeInfo? = e.source
        if (node == null) node = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (node == null) return false
        if (!node.isEditable) return false
        if (suppressNext || node.isPassword) return true

        val text = node.text?.toString() ?: return true
        if (text.isBlank()) return true
        val sep = when {
            text.endsWith(" ") -> " "
            text.endsWith("\n") -> "\n"
            else -> return true
        }

        val repl = Expander.buildReplacement(this, text) ?: return true
        val newText = repl + sep

        suppressNext = true
        val setArgs = Bundle()
        setArgs.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, newText)
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, setArgs)

        val selArgs = Bundle()
        selArgs.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, newText.length)
        selArgs.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, newText.length)
        node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, selArgs)

        handler.postDelayed(unsuppress, 160)
        return true
    }

    // ---------- чат-трекер ----------
    private fun requestScan() {
        if (!running) return
        if (SystemClock.uptimeMillis() - lastScan < 250) return
        if (inFlight.compareAndSet(false, true)) scanHandler?.post(scanOnce)
    }

    private fun runScan() {
        try {
            doScan()
        } catch (e: Exception) {
            Store.setDebug(this, "Ошибка сканирования: ${e.message}")
        } finally {
            inFlight.set(false)
        }
    }

    private fun doScan() {
        lastScan = SystemClock.uptimeMillis()
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (pkg == packageName) {
            hotNow = false
            return
        }
        val filter = Store.filterPkg(this)
        if (filter.isNotEmpty() && pkg != filter) {
            hotNow = false
            return
        }
        hotNow = isHot(pkg)

        if (pkg != lastPkg) {
            lastPkg = pkg
            seen.clear()
            seeded = false
        }

        val lines = ArrayList<String>()
        collect(root, lines, 0)

        // нашли строки чата: запоминаем приложение как игру, дальше опрос идёт чаще
        if (!hotNow && filter.isEmpty() && lines.any { Parser.looksLikeChat(it) }) {
            Store.addHotPkg(this, pkg)
            hotNow = true
            Store.addLog(this, "Игра найдена: $pkg (чат читается)")
        }

        val fresh = lines.filter { seen.add(it) }
        while (seen.size > 600) {
            val iter = seen.iterator()
            iter.next()
            iter.remove()
        }

        if (Store.checkMode(this)) {
            pkgInfo.remove(pkg)
            pkgInfo[pkg] = "строк ${lines.size}, новых ${fresh.size}"
            while (pkgInfo.size > 5) pkgInfo.remove(pkgInfo.keys.first())
            val keyLines = lines.filter { it.contains("<ADM>") }.takeLast(4)
            val hot = if (filter.isNotEmpty()) setOf(filter) else Store.hotPkgs(this)
            val sb = StringBuilder()
            sb.append("Игра: ")
            sb.append(if (hot.isEmpty()) "не найдена (зайди в чат игры и подожди)" else hot.joinToString(", "))
            sb.append("\n\nПриложения (последние сверху):")
            for (e in pkgInfo.entries.toList().asReversed()) {
                sb.append("\n• ").append(e.key).append(" — ").append(e.value)
            }
            sb.append("\n\n")
            if (keyLines.isEmpty()) {
                sb.append("Строк админ-чата («<ADM>») на экране нет.")
            } else {
                sb.append("Нужные строки:")
                for (k in keyLines) sb.append("\n• ").append(k.take(110))
            }
            Store.setDebug(this, sb.toString())
        }

        // Первое сканирование окна только запоминает видимую историю, без уведомлений
        if (!seeded) {
            seeded = true
            return
        }

        val hits = fresh.mapNotNull { l -> Parser.parse(l) }
        if (hits.isEmpty()) return
        if (hits.size > 8) {
            Store.addLog(this, "Пропущено ${hits.size} старых строк (загрузка истории чата)")
            return
        }
        handler.post { deliver(hits) }
    }

    // Выдача результатов в основном потоке: окно формы, уведомление, журнал
    private fun deliver(hits: List<Hit>) {
        for (h in hits) {
            overlay?.showForm(h.nick, h.command, false)
            Notifier.show(this, h.title, h.text)
            Store.addLog(this, "${h.title} — ${h.text}")
        }
    }

    // Читаем и text, и contentDescription, как GTAndroid
    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (n == null || depth > 40 || out.size > 4000) return
        val t = n.text?.toString()
        if (t != null) {
            for (part in t.split('\n')) if (part.isNotBlank()) out.add(part.trim())
        }
        val cd = n.contentDescription?.toString()
        if (cd != null && cd != t) {
            for (part in cd.split('\n')) if (part.isNotBlank()) out.add(part.trim())
        }
        for (i in 0 until n.childCount) {
            val c = n.getChild(i)
            collect(c, out, depth + 1)
            c?.recycle()
        }
    }
}
