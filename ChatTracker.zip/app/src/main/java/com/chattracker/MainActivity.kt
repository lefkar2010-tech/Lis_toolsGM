package com.chattracker

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import androidx.core.widget.doAfterTextChanged

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var dbg: TextView
    private lateinit var log: TextView
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 1000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        status = TextView(this).apply { textSize = 17f }
        val open = Button(this).apply {
            text = "Настройки спецвозможностей"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val pkg = EditText(this).apply {
            hint = "Пакет игры (пусто = все приложения)"
            setSingleLine()
            setText(Store.filterPkg(this@MainActivity))
            doAfterTextChanged { Store.setFilterPkg(this@MainActivity, it?.toString() ?: "") }
        }
        val sw = Switch(this).apply {
            text = "Режим проверки"
            isChecked = Store.checkMode(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Store.setCheckMode(this@MainActivity, v) }
        }
        val ac = Switch(this).apply {
            text = "Автокопирование формы в буфер"
            isChecked = Store.autoCopy(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Store.setAutoCopy(this@MainActivity, v) }
        }
        dbg = TextView(this).apply { textSize = 13f }
        val clear = Button(this).apply {
            text = "Очистить журнал"
            setOnClickListener { Store.clearLog(this@MainActivity); refresh() }
        }
        log = TextView(this).apply { textSize = 14f }
        val scroll = ScrollView(this).apply { addView(log) }

        root.addView(status)
        root.addView(open)
        root.addView(pkg)
        root.addView(sw)
        root.addView(ac)
        root.addView(dbg)
        root.addView(clear)
        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun serviceOn(): Boolean {
        val s = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/")
    }

    private fun refresh() {
        status.text = if (serviceOn()) "Служба: включена" else "Служба: выключена"
        dbg.text = if (Store.checkMode(this)) Store.debug(this) else ""
        val l = Store.getLog(this)
        log.text = if (l.isEmpty()) "Журнал пуст" else l.joinToString("\n\n")
    }
}
