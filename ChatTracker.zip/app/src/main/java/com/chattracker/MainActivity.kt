package com.chattracker

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.widget.doAfterTextChanged

class MainActivity : Activity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var status: TextView
    private lateinit var tabRules: Button
    private lateinit var tabReports: Button
    private lateinit var tabLog: Button
    private lateinit var rulesPanel: View
    private lateinit var reportsPanel: View
    private lateinit var logPanel: View

    private lateinit var statsText: TextView
    private lateinit var etShort: EditText
    private lateinit var etTemplate: EditText
    private lateinit var rulesList: LinearLayout

    private lateinit var reportsInfo: TextView
    private lateinit var reportsList: LinearLayout

    private lateinit var dbg: TextView
    private lateinit var logText: TextView

    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refreshStatus()
            h.postDelayed(this, 1500)
        }
    }
    private val prefListener =
        SharedPreferences.OnSharedPreferenceChangeListener { _, key -> onPrefChanged(key) }

    // ---------- вспомогательное ----------
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun label(s: String, size: Float, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun btn(s: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.setOnClickListener { onClick() }
        return b
    }

    private fun w1() = LinearLayout.LayoutParams(0, WRAP, 1f)

    private fun vbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        return l
    }

    private fun hbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        return l
    }

    // ---------- создание экрана ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        val root = vbox()
        root.setPadding(dp(12), dp(8), dp(12), dp(4))

        root.addView(label("Lis Tools GM", 22f, true))
        status = label("", 15f, false)
        root.addView(status)
        root.addView(btn("Открыть спецвозможности") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        val tabs = hbox()
        tabRules = btn("Правила") { showTab(0) }
        tabReports = btn("Репорты") { showTab(1) }
        tabLog = btn("Журнал") { showTab(2) }
        tabs.addView(tabRules, w1())
        tabs.addView(tabReports, w1())
        tabs.addView(tabLog, w1())
        root.addView(tabs)

        rulesPanel = buildRulesPanel()
        reportsPanel = buildReportsPanel()
        logPanel = buildLogPanel()

        val frame = FrameLayout(this)
        frame.addView(rulesPanel, FrameLayout.LayoutParams(MATCH, MATCH))
        frame.addView(reportsPanel, FrameLayout.LayoutParams(MATCH, MATCH))
        frame.addView(logPanel, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(frame, LinearLayout.LayoutParams(MATCH, 0, 1f))

        setContentView(root)
        showTab(1)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun buildRulesPanel(): View {
        val col = vbox()
        col.setPadding(0, dp(8), 0, dp(16))

        col.addView(label("Счётчики администратора", 16f, true))
        statsText = label("", 14f, false)
        col.addView(statsText)

        val newTitle = label("Новое правило", 16f, true)
        newTitle.setPadding(0, dp(14), 0, 0)
        col.addView(newTitle)

        etShort = EditText(this)
        etShort.hint = "Сокращение, например /dm"
        etShort.setSingleLine()
        etTemplate = EditText(this)
        etTemplate.hint = "Шаблон, например /jail {id} 60 DM"
        etTemplate.setSingleLine()
        col.addView(etShort)
        col.addView(etTemplate)
        col.addView(label("{id} подставляет число (ID), {text} подставляет остальной текст.", 12f, false))

        val row = hbox()
        row.addView(btn("Сохранить") { saveRuleFromForm() }, w1())
        row.addView(btn("Экспорт") { exportRules() }, w1())
        row.addView(btn("Импорт") { importRules() }, w1())
        col.addView(row)

        val listTitle = label("Мои правила", 16f, true)
        listTitle.setPadding(0, dp(14), 0, 0)
        col.addView(listTitle)
        rulesList = vbox()
        col.addView(rulesList)

        val sc = ScrollView(this)
        sc.addView(col)
        return sc
    }

    private fun buildReportsPanel(): View {
        val col = vbox()
        col.setPadding(0, dp(8), 0, 0)

        reportsInfo = label("", 14f, false)
        col.addView(reportsInfo)

        val row = hbox()
        row.addView(btn("Убрать выполненные") { Store.clearReports(this, true) }, w1())
        row.addView(btn("Очистить всё") { confirmClearReports() }, w1())
        col.addView(row)

        reportsList = vbox()
        val sc = ScrollView(this)
        sc.addView(reportsList)
        col.addView(sc, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return col
    }

    private fun buildLogPanel(): View {
        val col = vbox()
        col.setPadding(0, dp(8), 0, 0)

        val sw = Switch(this)
        sw.text = "Режим проверки (что видит служба)"
        sw.isChecked = Store.checkMode(this)
        sw.setOnCheckedChangeListener { _, v -> Store.setCheckMode(this@MainActivity, v) }
        col.addView(sw)

        val ac = Switch(this)
        ac.text = "Автокопирование формы в буфер"
        ac.isChecked = Store.autoCopy(this)
        ac.setOnCheckedChangeListener { _, v -> Store.setAutoCopy(this@MainActivity, v) }
        col.addView(ac)

        val pkg = EditText(this)
        pkg.hint = "Пакет игры для чат-трекера (пусто = все)"
        pkg.setSingleLine()
        pkg.setText(Store.filterPkg(this))
        pkg.doAfterTextChanged { Store.setFilterPkg(this@MainActivity, it?.toString() ?: "") }
        col.addView(pkg)
        col.addView(label("Автозамена работает везде, фильтр касается только чат-трекера.", 12f, false))

        dbg = label("", 12f, false)
        col.addView(dbg)
        col.addView(btn("Очистить журнал") { Store.clearLog(this) })

        logText = label("", 14f, false)
        logText.setTextIsSelectable(true)
        val sc = ScrollView(this)
        sc.addView(logText)
        col.addView(sc, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return col
    }

    private fun showTab(i: Int) {
        val panels = listOf(rulesPanel, reportsPanel, logPanel)
        for (idx in panels.indices) {
            panels[idx].visibility = if (idx == i) View.VISIBLE else View.GONE
        }
        val tabs = listOf(tabRules, tabReports, tabLog)
        for (idx in tabs.indices) {
            tabs[idx].alpha = if (idx == i) 1f else 0.5f
        }
    }

    // ---------- жизненный цикл ----------
    override fun onResume() {
        super.onResume()
        Store.prefs(this).registerOnSharedPreferenceChangeListener(prefListener)
        refreshAll()
        h.post(tick)
    }

    override fun onPause() {
        super.onPause()
        Store.prefs(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        h.removeCallbacks(tick)
    }

    private fun onPrefChanged(key: String?) {
        when (key) {
            "rules" -> renderRules()
            "stats" -> statsText.text = Store.statsSummary(this)
            "reports" -> renderReports()
            "log" -> renderLog()
            "debug", "check" -> renderDebug()
        }
    }

    private fun refreshAll() {
        refreshStatus()
        statsText.text = Store.statsSummary(this)
        renderRules()
        renderReports()
        renderLog()
        renderDebug()
    }

    private fun serviceOn(): Boolean {
        val s = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return s.contains("$packageName/")
    }

    private fun refreshStatus() {
        status.text = if (serviceOn()) "Служба: включена"
        else "Служба: выключена. Включи её в спецвозможностях"
    }

    private fun renderDebug() {
        dbg.text = if (Store.checkMode(this)) Store.debug(this) else ""
    }

    private fun renderLog() {
        val l = Store.getLog(this)
        logText.text = if (l.isEmpty()) "Журнал пуст" else l.joinToString("\n\n")
    }

    // ---------- репорты ----------
    private fun renderReports() {
        val list = Store.getReports(this)
        val pending = list.count { !it.done }
        reportsInfo.text = if (list.isEmpty()) {
            "Репортов пока нет. Они появятся, когда служба увидит их в чате игры."
        } else {
            "Ожидают: $pending из ${list.size}. Нажми на репорт, чтобы отметить выполненным, удерживай для удаления."
        }
        tabReports.text = if (pending > 0) "Репорты ($pending)" else "Репорты"

        reportsList.removeAllViews()
        for (r in list) {
            val item = hbox()
            item.gravity = Gravity.CENTER_VERTICAL
            item.setPadding(0, dp(6), 0, dp(6))
            item.alpha = if (r.done) 0.45f else 1f

            val mark = if (r.done) "✓" else "●"
            val msg = if (r.msg.isNotEmpty()) r.msg else "(без текста)"
            val tv = TextView(this)
            tv.textSize = 15f
            tv.text = "$mark ${r.time}  ${r.nick}[${r.pid}]\n$msg · очередь: ${r.queue}"
            tv.setOnClickListener { Store.toggleReport(this@MainActivity, r.uid) }
            tv.setOnLongClickListener {
                confirmDeleteReport(r)
                true
            }
            item.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
            item.addView(btn("ID") {
                Clip.copy(this@MainActivity, r.pid)
                toast("ID ${r.pid} скопирован")
            }, LinearLayout.LayoutParams(WRAP, WRAP))
            reportsList.addView(item)
        }
    }

    private fun confirmDeleteReport(r: Report) {
        AlertDialog.Builder(this)
            .setTitle("Удалить репорт?")
            .setMessage("${r.nick}[${r.pid}]: ${r.msg}")
            .setPositiveButton("Удалить") { _, _ -> Store.deleteReport(this, r.uid) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun confirmClearReports() {
        AlertDialog.Builder(this)
            .setTitle("Очистить весь список репортов?")
            .setPositiveButton("Очистить") { _, _ -> Store.clearReports(this, false) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    // ---------- правила ----------
    private fun renderRules() {
        rulesList.removeAllViews()
        val rules = Store.loadRules(this)
        if (rules.isEmpty()) {
            rulesList.addView(label("Правил нет", 14f, false))
            return
        }
        for (r in rules) {
            val item = vbox()
            item.setPadding(0, dp(6), 0, dp(6))
            item.addView(label("${r.shortCommand} → ${r.outputTemplate}", 15f, true))
            item.addView(label("Пример: ${r.preview()}", 12f, false))
            val row = hbox()
            row.addView(btn("Изменить") { editRule(r) }, w1())
            row.addView(btn("Удалить") { deleteRule(r) }, w1())
            item.addView(row)
            rulesList.addView(item)
        }
    }

    private fun upsertRule(oldShort: String?, shortRaw: String, tplRaw: String): Boolean {
        val s = shortRaw.trim()
        val t = tplRaw.trim()
        if (!s.startsWith("/") || s.length < 2 || s.any { it.isWhitespace() }) {
            toast("Сокращение должно начинаться с / и быть без пробелов")
            return false
        }
        if (t.isEmpty()) {
            toast("Шаблон пустой")
            return false
        }
        val list = Store.loadRules(this).toMutableList()
        if (oldShort != null) list.removeAll { it.shortCommand.equals(oldShort, ignoreCase = true) }
        val i = list.indexOfFirst { it.shortCommand.equals(s, ignoreCase = true) }
        val rule = Rule(s, t)
        if (i >= 0) list[i] = rule else list.add(rule)
        Store.saveRules(this, list)
        return true
    }

    private fun saveRuleFromForm() {
        if (upsertRule(null, etShort.text.toString(), etTemplate.text.toString())) {
            etShort.setText("")
            etTemplate.setText("")
            toast("Сохранено")
        }
    }

    private fun editRule(r: Rule) {
        val box = vbox()
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val s = EditText(this)
        s.setText(r.shortCommand)
        s.setSingleLine()
        val t = EditText(this)
        t.setText(r.outputTemplate)
        t.setSingleLine()
        box.addView(s)
        box.addView(t)
        AlertDialog.Builder(this)
            .setTitle("Правило")
            .setView(box)
            .setPositiveButton("Сохранить") { _, _ ->
                upsertRule(r.shortCommand, s.text.toString(), t.text.toString())
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun deleteRule(r: Rule) {
        val list = Store.loadRules(this).filter { !it.shortCommand.equals(r.shortCommand, ignoreCase = true) }
        Store.saveRules(this, list)
        toast("Удалено")
    }

    private fun clipText(): String {
        val cm = getSystemService(ClipboardManager::class.java)
        val clip = cm.primaryClip
        return if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this).toString() else ""
    }

    private fun exportRules() {
        Clip.copy(this, Store.exportRulesJson(this))
        toast("Правила скопированы в буфер (JSON)")
    }

    private fun importRules() {
        val et = EditText(this)
        et.hint = "Вставь JSON с правилами"
        et.minLines = 4
        val cb = clipText().trim()
        if (cb.startsWith("{") || cb.startsWith("[")) et.setText(cb)
        val box = vbox()
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(et)
        AlertDialog.Builder(this)
            .setTitle("Импорт правил")
            .setView(box)
            .setPositiveButton("Импортировать") { _, _ ->
                try {
                    val n = Store.importRulesJson(this, et.text.toString())
                    toast("Импортировано правил: $n")
                } catch (e: Exception) {
                    toast("Неверный JSON")
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }
}
