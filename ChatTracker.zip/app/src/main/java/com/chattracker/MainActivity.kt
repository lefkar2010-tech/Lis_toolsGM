package com.chattracker

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.InsetDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.widget.doAfterTextChanged

class MainActivity : Activity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var status: TextView
    private lateinit var tabRules: Button
    private lateinit var tabReports: Button
    private lateinit var tabLog: Button
    private lateinit var rulesPanel: View
    private lateinit var reportsPanel: View
    private lateinit var logPanel: View

    private lateinit var statsText: TextView
    private lateinit var etShort: EditText
    private lateinit var etTemplate: EditText
    private lateinit var rulesList: LinearLayout

    private lateinit var reportsInfo: TextView
    private lateinit var reportsList: LinearLayout

    private lateinit var dbg: TextView
    private lateinit var logText: TextView

    private val REQ_EXPORT = 101
    private val REQ_IMPORT = 102

    private var currentTab = 1

    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refreshStatus()
            h.postDelayed(this, 1500)
        }
    }
    private val prefListener =
        SharedPreferences.OnSharedPreferenceChangeListener { _, key -> onPrefChanged(key) }

    // ---------- оформление ----------
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun label(s: String, size: Float, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(if (size <= 12f) Ui.MUTED else Ui.TEXT)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun btn(s: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.transformationMethod = null
        b.setTextColor(Ui.TEXT)
        b.textSize = 14f
        b.minHeight = 0
        b.minimumHeight = dp(46)
        b.background = InsetDrawable(Ui.button(dp(12).toFloat()), dp(3))
        b.stateListAnimator = null
        b.setOnClickListener { onClick() }
        return b
    }

    private fun styleTab(b: Button, selected: Boolean) {
        val normal = if (selected) Ui.BURGUNDY_LIGHT else Ui.FIELD
        b.background = InsetDrawable(Ui.stateful(normal, Ui.BURGUNDY_DARK, dp(12).toFloat()), dp(3))
        b.setTextColor(if (selected) Ui.TEXT else Ui.MUTED)
    }

    private fun field(hint: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setSingleLine()
        e.setTextColor(Ui.TEXT)
        e.setHintTextColor(Ui.MUTED)
        e.background = Ui.rounded(Ui.FIELD, dp(10).toFloat())
        e.setPadding(dp(12), dp(10), dp(12), dp(10))
        return e
    }

    private fun fieldLp(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.setMargins(0, dp(4), 0, dp(4))
        return lp
    }

    private fun cardLp(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.setMargins(0, 0, 0, dp(6))
        return lp
    }

    private fun tint(sw: Switch) {
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(Ui.BURGUNDY_LIGHT, Ui.MUTED))
        sw.trackTintList = ColorStateList(states, intArrayOf(Ui.BURGUNDY_DARK, 0xFF3A3A42.toInt()))
        sw.setTextColor(Ui.TEXT)
    }

    private fun dialog(): AlertDialog.Builder =
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)

    private fun w1() = LinearLayout.LayoutParams(0, WRAP, 1f)

    private fun vbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        return l
    }

    private fun hbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        return l
    }

    private fun card(): LinearLayout {
        val l = vbox()
        l.setPadding(dp(12), dp(10), dp(12), dp(10))
        l.background = Ui.rounded(Ui.CARD, dp(14).toFloat())
        return l
    }

    // ---------- создание экрана ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG

        val root = vbox()
        root.setBackgroundColor(Ui.BG)
        root.setPadding(dp(12), dp(14), dp(12), dp(4))

        root.addView(label("Lis Tools GM", 24f, true))
        status = label("", 15f, false)
        status.setPadding(0, dp(2), 0, dp(4))
        root.addView(status)
        root.addView(btn("Открыть спецвозможности") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        val tabs = hbox()
        tabRules = btn("Правила") { showTab(0) }
        tabReports = btn("Репорты") { showTab(1) }
        tabLog = btn("Журнал") { showTab(2) }
        tabs.addView(tabRules, w1())
        tabs.addView(tabReports, w1())
        tabs.addView(tabLog, w1())
        root.addView(tabs)

        rulesPanel = buildRulesPanel()
        reportsPanel = buildReportsPanel()
        logPanel = buildLogPanel()

        val frame = FrameLayout(this)
        frame.addView(rulesPanel, FrameLayout.LayoutParams(MATCH, MATCH))
        frame.addView(reportsPanel, FrameLayout.LayoutParams(MATCH, MATCH))
        frame.addView(logPanel, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(frame, LinearLayout.LayoutParams(MATCH, 0, 1f))

        setContentView(root)
        showTab(currentTab)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun buildRulesPanel(): View {
        val col = vbox()
        col.setPadding(0, dp(8), 0, dp(16))

        col.addView(label("Счётчики администратора", 16f, true))
        val statsCard = card()
        statsText = label("", 14f, false)
        statsCard.addView(statsText)
        val statsLp = LinearLayout.LayoutParams(MATCH, WRAP)
        statsLp.setMargins(0, dp(4), 0, 0)
        col.addView(statsCard, statsLp)

        val newTitle = label("Новое правило", 16f, true)
        newTitle.setPadding(0, dp(14), 0, 0)
        col.addView(newTitle)

        etShort = field("Сокращение, например /dm")
        etTemplate = field("Шаблон, например /jail {id} 60 DM")
        col.addView(etShort, fieldLp())
        col.addView(etTemplate, fieldLp())
        col.addView(label("{id} подставляет число (ID), {text} подставляет остальной текст.", 12f, false))

        val row = hbox()
        row.addView(btn("Сохранить") { saveRuleFromForm() }, w1())
        row.addView(btn("Экспорт") { exportRules() }, w1())
        row.addView(btn("Импорт") { importRules() }, w1())
        col.addView(row)

        val listTitle = label("Мои правила", 16f, true)
        listTitle.setPadding(0, dp(14), 0, dp(4))
        col.addView(listTitle)
        rulesList = vbox()
        col.addView(rulesList)

        val sc = ScrollView(this)
        sc.addView(col)
        return sc
    }

    private fun buildReportsPanel(): View {
        val col = vbox()
        col.setPadding(0, dp(8), 0, 0)

        reportsInfo = label("", 14f, false)
        reportsInfo.setPadding(0, 0, 0, dp(4))
        col.addView(reportsInfo)

        val row = hbox()
        row.addView(btn("Убрать выполненные") { Store.clearReports(this, true) }, w1())
        row.addView(btn("Очистить всё") { confirmClearReports() }, w1())
        col.addView(row)

        reportsList = vbox()
        val sc = ScrollView(this)
        sc.addView(reportsList)
        val scLp = LinearLayout.LayoutParams(MATCH, 0, 1f)
        scLp.setMargins(0, dp(6), 0, 0)
        col.addView(sc, scLp)
        return col
    }

    private fun buildLogPanel(): View {
        val col = vbox()
        col.setPadding(0, dp(8), 0, dp(16))

        val sw = Switch(this)
        sw.text = "Кружок с репортами поверх игры"
        sw.isChecked = Store.overlayOn(this)
        sw.setOnCheckedChangeListener { _, v -> Store.setOverlayOn(this@MainActivity, v) }
        tint(sw)
        col.addView(sw)

        val chk = Switch(this)
        chk.text = "Режим проверки (что видит служба)"
        chk.isChecked = Store.checkMode(this)
        chk.setOnCheckedChangeListener { _, v -> Store.setCheckMode(this@MainActivity, v) }
        tint(chk)
        col.addView(chk)

        val ac = Switch(this)
        ac.text = "Автокопирование формы в буфер"
        ac.isChecked = Store.autoCopy(this)
        ac.setOnCheckedChangeListener { _, v -> Store.setAutoCopy(this@MainActivity, v) }
        tint(ac)
        col.addView(ac)

        val pkg = field("Пакет игры (необязательно, находится сам)")
        pkg.setText(Store.filterPkg(this))
        pkg.doAfterTextChanged { Store.setFilterPkg(this@MainActivity, it?.toString() ?: "") }
        col.addView(pkg, fieldLp())

        val nick = field("Мой ник (свои формы не показывать)")
        nick.setText(Store.myNick(this))
        nick.doAfterTextChanged { Store.setMyNick(this@MainActivity, it?.toString() ?: "") }
        col.addView(nick, fieldLp())
        col.addView(label("Игра определяется сама: зайди в чат игры и подожди несколько секунд. Пакет можно задать вручную.", 12f, false))

        val tests = hbox()
        tests.addView(btn("Тест формы") { Store.requestTestForm(this) }, w1())
        tests.addView(btn("Тест репорта") {
            Store.addReport(this, "", "Test_Player", "1", "тестовый репорт", 3)
        }, w1())
        col.addView(tests)
        col.addView(btn("Сбросить найденную игру") { Store.clearHotPkgs(this) })

        dbg = label("", 12f, false)
        dbg.setPadding(0, dp(6), 0, dp(6))
        dbg.setTextIsSelectable(true)
        col.addView(dbg)
        col.addView(btn("Очистить журнал") { Store.clearLog(this) })

        logText = label("", 14f, false)
        logText.setTextIsSelectable(true)
        logText.setPadding(0, dp(8), 0, 0)
        col.addView(logText)

        val sc = ScrollView(this)
        sc.addView(col)
        return sc
    }

    private fun showTab(i: Int) {
        currentTab = i
        val panels = listOf(rulesPanel, reportsPanel, logPanel)
        for (idx in panels.indices) {
            panels[idx].visibility = if (idx == i) View.VISIBLE else View.GONE
        }
        val tabs = listOf(tabRules, tabReports, tabLog)
        for (idx in tabs.indices) styleTab(tabs[idx], idx == i)
    }

    // ---------- жизненный цикл ----------
    override fun onResume() {
        super.onResume()
        Store.prefs(this).registerOnSharedPreferenceChangeListener(prefListener)
        refreshAll()
        h.post(tick)
    }

    override fun onPause() {
        super.onPause()
        Store.prefs(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        h.removeCallbacks(tick)
    }

    private fun onPrefChanged(key: String?) {
        when (key) {
            "rules" -> renderRules()
            "stats" -> statsText.text = Store.statsSummary(this)
            "reports" -> renderReports()
            "log" -> renderLog()
            "debug", "check" -> renderDebug()
        }
    }

    private fun refreshAll() {
        refreshStatus()
        statsText.text = Store.statsSummary(this)
        renderRules()
        renderReports()
        renderLog()
        renderDebug()
    }

    private fun serviceOn(): Boolean {
        val s = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return s.contains("$packageName/")
    }

    private fun refreshStatus() {
        status.text = if (serviceOn()) "Служба: включена"
        else "Служба: выключена. Включи её в спецвозможностях"
    }

    private fun renderDebug() {
        dbg.text = if (Store.checkMode(this)) Store.debug(this) else ""
    }

    private fun renderLog() {
        val l = Store.getLog(this)
        logText.text = if (l.isEmpty()) "Журнал пуст" else l.joinToString("\n\n")
    }

    // ---------- репорты ----------
    private fun renderReports() {
        val list = Store.getReports(this)
        val pending = list.count { !it.done }
        reportsInfo.text = if (list.isEmpty()) {
            "Репортов пока нет. Они появятся, когда служба увидит их в чате игры."
        } else {
            "Ожидают: $pending из ${list.size}. Нажми на репорт, чтобы отметить выполненным, удерживай для удаления."
        }
        tabReports.text = if (pending > 0) "Репорты ($pending)" else "Репорты"

        reportsList.removeAllViews()
        for (r in list) {
            val item = hbox()
            item.gravity = Gravity.CENTER_VERTICAL
            item.setPadding(dp(12), dp(8), dp(8), dp(8))
            item.background = Ui.rounded(Ui.CARD, dp(14).toFloat())
            item.alpha = if (r.done) 0.45f else 1f

            val mark = if (r.done) "✓" else "●"
            val msg = if (r.msg.isNotEmpty()) r.msg else "(без текста)"
            val tv = TextView(this)
            tv.textSize = 15f
            tv.setTextColor(Ui.TEXT)
            tv.text = "$mark ${r.time}  ${r.nick}[${r.pid}]\n$msg · очередь: ${r.queue}"
            tv.setOnClickListener { Store.toggleReport(this@MainActivity, r.uid) }
            tv.setOnLongClickListener {
                confirmDeleteReport(r)
                true
            }
            item.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
            item.addView(btn("ID") {
                Clip.copy(this@MainActivity, r.pid)
                toast("ID ${r.pid} скопирован")
            }, LinearLayout.LayoutParams(WRAP, WRAP))
            reportsList.addView(item, cardLp())
        }
    }

    private fun confirmDeleteReport(r: Report) {
        dialog()
            .setTitle("Удалить репорт?")
            .setMessage("${r.nick}[${r.pid}]: ${r.msg}")
            .setPositiveButton("Удалить") { _, _ -> Store.deleteReport(this, r.uid) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun confirmClearReports() {
        dialog()
            .setTitle("Очистить весь список репортов?")
            .setPositiveButton("Очистить") { _, _ -> Store.clearReports(this, false) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    // ---------- правила ----------
    private fun renderRules() {
        rulesList.removeAllViews()
        val rules = Store.loadRules(this)
        if (rules.isEmpty()) {
            rulesList.addView(label("Правил нет", 14f, false))
            return
        }
        for (r in rules) {
            val item = card()
            item.addView(label("${r.shortCommand} → ${r.outputTemplate}", 15f, true))
            item.addView(label("Пример: ${r.preview()}", 12f, false))
            val row = hbox()
            row.addView(btn("Изменить") { editRule(r) }, w1())
            row.addView(btn("Удалить") { deleteRule(r) }, w1())
            item.addView(row)
            rulesList.addView(item, cardLp())
        }
    }

    private fun upsertRule(oldShort: String?, shortRaw: String, tplRaw: String): Boolean {
        val s = shortRaw.trim()
        val t = tplRaw.trim()
        if (!s.startsWith("/") || s.length < 2 || s.any { it.isWhitespace() }) {
            toast("Сокращение должно начинаться с / и быть без пробелов")
            return false
        }
        if (t.isEmpty()) {
            toast("Шаблон пустой")
            return false
        }
        val list = Store.loadRules(this).toMutableList()
        if (oldShort != null) list.removeAll { it.shortCommand.equals(oldShort, ignoreCase = true) }
        val i = list.indexOfFirst { it.shortCommand.equals(s, ignoreCase = true) }
        val rule = Rule(s, t)
        if (i >= 0) list[i] = rule else list.add(rule)
        Store.saveRules(this, list)
        return true
    }

    private fun saveRuleFromForm() {
        if (upsertRule(null, etShort.text.toString(), etTemplate.text.toString())) {
            etShort.setText("")
            etTemplate.setText("")
            toast("Сохранено")
        }
    }

    private fun editRule(r: Rule) {
        val box = vbox()
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val s = field("Сокращение")
        s.setText(r.shortCommand)
        val t = field("Шаблон")
        t.setText(r.outputTemplate)
        box.addView(s, fieldLp())
        box.addView(t, fieldLp())
        dialog()
            .setTitle("Правило")
            .setView(box)
            .setPositiveButton("Сохранить") { _, _ ->
                upsertRule(r.shortCommand, s.text.toString(), t.text.toString())
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun deleteRule(r: Rule) {
        val list = Store.loadRules(this).filter { !it.shortCommand.equals(r.shortCommand, ignoreCase = true) }
        Store.saveRules(this, list)
        toast("Удалено")
    }

    // ---------- экспорт / импорт файлом ----------
    private fun exportRules() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/json"
        i.putExtra(Intent.EXTRA_TITLE, "lis_tools_rules.json")
        try {
            startActivityForResult(i, REQ_EXPORT)
        } catch (e: Exception) {
            toast("Не удалось открыть выбор файла")
        }
    }

    private fun importRules() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        try {
            startActivityForResult(i, REQ_IMPORT)
        } catch (e: Exception) {
            toast("Не удалось открыть выбор файла")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return

        if (requestCode == REQ_EXPORT) {
            try {
                val json = Store.exportRulesJson(this)
                val out = contentResolver.openOutputStream(uri, "wt")
                if (out == null) {
                    toast("Не удалось записать файл")
                    return
                }
                out.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                toast("Правила сохранены в файл")
            } catch (e: Exception) {
                toast("Ошибка записи файла")
            }
        } else if (requestCode == REQ_IMPORT) {
            try {
                val input = contentResolver.openInputStream(uri)
                if (input == null) {
                    toast("Не удалось прочитать файл")
                    return
                }
                val bytes = input.use { it.readBytes() }
                if (bytes.size > 1_000_000) {
                    toast("Файл слишком большой")
                    return
                }
                val text = String(bytes, Charsets.UTF_8).removePrefix("\uFEFF")
                val n = Store.importRulesJson(this, text)
                toast(if (n > 0) "Импортировано правил: $n" else "В файле нет правил")
            } catch (e: Exception) {
                toast("Неверный файл: нужен JSON с правилами")
            }
        }
    }
}
