package com.chattracker

// Форма от админа: command — готовая строка для чата, nick — кто прислал
data class Hit(
    val kind: String,
    val title: String,
    val text: String,
    val command: String,
    val nick: String
)

object Parser {
    private val colorCode = Regex("""\{[0-9A-Fa-f]{6}\}""")
    private val TS = """(?:\[?\d{1,2}:\d{2}(?::\d{2})?\]?\s*)?"""
    private val NICK = """[^\s\[\]():]+"""

    // <ADM> (3) Ник[16]: /команда ...   (перед "/" только один пробел-разделитель)
    private val formLine = Regex("""^${TS}<ADM>\s*(?:\(\d+\)\s*)?(${NICK})[\[(]\d+[\])]:\s?(/.*)""")
    private val chatLike = Regex("""^\s*(?:\d{1,2}:\d{2}\s*)?(?:[^\s\[\]():]+[\[(]\d+[\])]|<ADM>)""")

    // Разрешённые команды
    private val simple = Regex("""/(slap|spawn|uncaff|untie|spcar|rgun|skick)\s+(\d+)""")
    private val timed = Regex("""/(jail|mute|ban)\s+(\d+)\s+(\S+)\s+(\S.*)""")
    private val reasoned = Regex("""/(warn|kick)\s+(\d+)\s+(\S.*)""")

    // Строка похожа на строку игрового чата (по ней находим пакет игры)
    fun looksLikeChat(raw: String): Boolean {
        val s = raw.replace(colorCode, "").trim()
        if (s.contains("<ADM>") || s.contains("репорта")) return true
        return s.contains("]:") && chatLike.containsMatchIn(s)
    }

    // Lis_Myr -> L.Myr
    private fun initials(nick: String): String {
        val p = nick.split('_').filter { it.isNotEmpty() }
        return if (p.size >= 2) "${p.first().first()}.${p.last()}" else nick
    }

    fun parse(raw: String): Hit? {
        val s = raw.replace(colorCode, "").trim()
        val m = formLine.find(s) ?: return null
        val nick = m.groupValues[1]
        val msg = m.groupValues[2].trimEnd()

        simple.matchEntire(msg)?.let { c ->
            return Hit("form", "Форма /${c.groupValues[1]}", "ID ${c.groupValues[2]} · $msg", msg, nick)
        }
        timed.matchEntire(msg)?.let { c ->
            val full = "$msg | ${initials(nick)}"
            return Hit("form", "Форма /${c.groupValues[1]}", "ID ${c.groupValues[2]} · $full", full, nick)
        }
        reasoned.matchEntire(msg)?.let { c ->
            val full = "$msg | ${initials(nick)}"
            return Hit("form", "Форма /${c.groupValues[1]}", "ID ${c.groupValues[2]} · $full", full, nick)
        }
        return null
    }
}
