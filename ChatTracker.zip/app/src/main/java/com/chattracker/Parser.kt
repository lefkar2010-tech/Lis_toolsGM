package com.chattracker

data class Hit(val kind: String, val title: String, val text: String, val copy: String? = null)

object Parser {
    private val TS = """(?:\[\d{2}:\d{2}:\d{2}\]\s*)?"""
    private val NICK = """[^\s\[\]:]+"""

    // [19:15:43] Flowing_Miller[88]: дб [К-во репорта: 6]
    private val report = Regex("^" + TS + NICK + """\[(\d+)\]:.*\[К-во репорта:\s*(\d+)\]""")

    // >>> В СЕТИ: Dumdaia_Karaew[73]: бан тут (5.2 ОП 31д)
    private val botDetail = Regex(""">>>\s*В СЕТИ:\s*""" + NICK + """\[(\d+)\]:.*?\(([^()]+?)\s+(\d+\s*[^\s()]*)\)""")

    // <ADM> (3) Ник[16]: /команда ...
    // После "Ник[ID]:" допустим максимум один разделительный пробел, затем СРАЗУ "/".
    private val formLine = Regex("^" + TS + """<ADM>\s*\(\d+\)\s*(""" + NICK + """)\[\d+\]:\s?(/.*)""")

    // Разрешённые команды
    private val simple = Regex("""/(slap|spawn|uncaff|untie|spcar|rgun|skick)\s+(\d+)""")
    private val timed = Regex("""/(jail|mute|ban)\s+(\d+)\s+(\S+)\s+(\S.*)""")
    private val reasoned = Regex("""/(warn|kick)\s+(\d+)\s+(\S.*)""")

    // Lis_Myr -> L.Myr
    private fun initials(nick: String): String {
        val p = nick.split('_').filter { it.isNotEmpty() }
        return if (p.size >= 2) "${p.first().first()}.${p.last()}" else nick
    }

    fun parse(raw: String): Hit? {
        val s = raw.trim()

        if (s.contains("Grnd_Bot[") && s.contains(">>>")) {
            botDetail.find(s)?.let { m ->
                return Hit(
                    "bot", "Grnd_Bot: игрок в сети",
                    "ID ${m.groupValues[1]} · ${m.groupValues[2].trim()} · ${m.groupValues[3].trim()}"
                )
            }
            return Hit("bot", "Grnd_Bot", s.substringAfter(">>>").trim().take(120))
        }

        report.find(s)?.let { m ->
            return Hit("report", "Репорт", "ID ${m.groupValues[1]} · в очереди: ${m.groupValues[2]}")
        }

        formLine.find(s)?.let { m ->
            val nick = m.groupValues[1]
            val msg = m.groupValues[2].trimEnd()

            simple.matchEntire(msg)?.let { c ->
                return Hit("form", "Форма /${c.groupValues[1]}", "ID ${c.groupValues[2]} · $msg", msg)
            }
            timed.matchEntire(msg)?.let { c ->
                val full = "$msg | ${initials(nick)}"
                return Hit("form", "Форма /${c.groupValues[1]}", "ID ${c.groupValues[2]} · $full", full)
            }
            reasoned.matchEntire(msg)?.let { c ->
                val full = "$msg | ${initials(nick)}"
                return Hit("form", "Форма /${c.groupValues[1]}", "ID ${c.groupValues[2]} · $full", full)
            }
        }

        return null
    }
}
