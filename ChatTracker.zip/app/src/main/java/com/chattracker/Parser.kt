package com.chattracker

data class Hit(
    val kind: String,
    val title: String,
    val text: String,
    val copy: String? = null,
    val time: String = "",
    val nick: String = "",
    val pid: String = "",
    val msg: String = "",
    val queue: Int = 0
)

// Строка вида "<ADM> Админ[ID] ответил Игрок[ID]: ..." (кто-то ответил на репорт)
data class Answer(val admin: String, val pid: String)

object Parser {
    private val colorCode = Regex("""\{[0-9A-Fa-f]{6}\}""")
    private val TS = """(?:\[?\d{1,2}:\d{2}(?::\d{2})?\]?\s*)?"""
    private val NICK = """[^\s\[\]():]+"""

    // 11:00 Alan_Makarav[286]: где находится 8 бит? [К-во репорта: 1]
    // (время бывает "11:00", "[11:00]" и "[19:15:43]"; ID в [] или в ())
    private val report = Regex(
        """^(?:\[?(\d{1,2}:\d{2}(?::\d{2})?)\]?\s*)?(${NICK})[\[(](\d+)[\])]:\s*(.*?)\s*\[К-?во репорта:?\s*(\d+)\s*\]"""
    )

    // 11:00 <ADM> Lis_Myr[506] ответил Aleks_Iksanov[90]: текст ответа
    private val answerLine = Regex(
        """^${TS}<ADM>\s*(?:\(\d+\)\s*)?(${NICK})[\[(]\d+[\])]:?\s+ответил\s+(${NICK})[\[(](\d+)[\])]"""
    )

    // <ADM> (3) Ник[16]: /команда ...
    // После "Ник[ID]:" допустим максимум один разделительный пробел, затем СРАЗУ "/".
    private val formLine = Regex("""^${TS}<ADM>\s*(?:\(\d+\)\s*)?(${NICK})[\[(]\d+[\])]:\s?(/.*)""")

    // Хвост "[К-во репорта: N]", перенесённый на отдельную строку
    private val cont = Regex("""^\[К-?во репорта:?\s*\d+\s*\]""")
    private val chatLike = Regex("""^\s*(?:\d{1,2}:\d{2}\s*)?(?:[^\s\[\]():]+[\[(]\d+[\])]|<ADM>)""")

    // Разрешённые команды
    private val simple = Regex("""/(slap|spawn|uncaff|untie|spcar|rgun|skick)\s+(\d+)""")
    private val timed = Regex("""/(jail|mute|ban)\s+(\d+)\s+(\S+)\s+(\S.*)""")
    private val reasoned = Regex("""/(warn|kick)\s+(\d+)\s+(\S.*)""")

    // Строка похожа на строку игрового чата (по ней находим пакет игры)
    fun looksLikeChat(raw: String): Boolean {
        val s = raw.replace(colorCode, "").trim()
        if (s.contains("<ADM>") || s.contains("репорта")) return true
        return s.contains("]:") && chatLike.containsMatchIn(s)
    }

    fun mergeContinuations(lines: List<String>): List<String> {
        val out = ArrayList<String>()
        for (l in lines) {
            val t = l.trim()
            if (out.isNotEmpty() && cont.containsMatchIn(t)) {
                out[out.size - 1] = out[out.size - 1] + " " + t
            } else {
                out.add(l)
            }
        }
        return out
    }

    // Lis_Myr -> L.Myr
    private fun initials(nick: String): String {
        val p = nick.split('_').filter { it.isNotEmpty() }
        return if (p.size >= 2) "${p.first().first()}.${p.last()}" else nick
    }

    fun answerOf(raw: String): Answer? {
        val s = raw.replace(colorCode, "").trim()
        val m = answerLine.find(s) ?: return null
        return Answer(m.groupValues[1], m.groupValues[3])
    }

    fun parse(raw: String): Hit? {
        val s = raw.replace(colorCode, "").trim()

        report.find(s)?.let { m ->
            val g = m.groupValues
            val msg = g[4].trim()
            val shown = if (msg.isEmpty()) "" else " · $msg"
            return Hit(
                "report", "Репорт", "ID ${g[3]}$shown · в очереди: ${g[5]}",
                null, g[1], g[2], g[3], msg, g[5].toIntOrNull() ?: 0
            )
        }

        formLine.find(s)?.let { m ->
            val nick = m.groupValues[1]
            val msg = m.groupValues[2].trimEnd()

            simple.matchEntire(msg)?.let { c ->
                return Hit("form", "Форма /${c.groupValues[1]}", "ID ${c.groupValues[2]} · $msg", msg, nick = nick)
            }
            timed.matchEntire(msg)?.let { c ->
                val full = "$msg | ${initials(nick)}"
                return Hit("form", "Форма /${c.groupValues[1]}", "ID ${c.groupValues[2]} · $full", full, nick = nick)
            }
            reasoned.matchEntire(msg)?.let { c ->
                val full = "$msg | ${initials(nick)}"
                return Hit("form", "Форма /${c.groupValues[1]}", "ID ${c.groupValues[2]} · $full", full, nick = nick)
            }
        }

        return null
    }
}
