package com.chattracker

import android.content.Context

// Автозамена: "/dm 22 " -> "/jail 22 60 DM "
object Expander {
    private val cmdRegex = Regex("""(^|\s)(/\S+)(?:\s+(.*))?$""")
    private val idText = Regex("""^(\d+)(?:\s+(.*))?$""")
    private val idOnly = Regex("""^\d+$""")

    fun buildReplacement(c: Context, text: String): String? {
        val t = text.trimEnd()
        val m = cmdRegex.find(t) ?: return null
        val cmd = m.groupValues[2]
        val rest = m.groupValues[3].trim()
        val prefix = t.substring(0, m.range.first).trimEnd()

        val rule = Store.loadRules(c).firstOrNull {
            it.shortCommand.equals(cmd, ignoreCase = true)
        } ?: return null

        val expanded = expandRule(rule, rest) ?: return null
        Store.recordCommand(c, expanded)
        return if (prefix.isBlank()) expanded else "$prefix $expanded"
    }

    fun expandRule(rule: Rule, rest: String): String? {
        val needId = rule.requiresId()
        val needText = rule.acceptsText()
        return when {
            needId && needText -> {
                val m = idText.find(rest) ?: return null
                rule.expand(m.groupValues[1], m.groupValues[2])
            }
            needId -> if (idOnly.matches(rest)) rule.expand(rest) else null
            needText -> if (rest.isBlank()) null else rule.expand("", rest)
            else -> rule.expand()
        }
    }
}
