package com.chattracker

import android.content.Context
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.min

data class FormItem(val nick: String, val command: String, val test: Boolean)

// Окно формы от админа поверх игры: «Выдать» отправляет команду прямо в чат игры
class OverlayManager(private val svc: TrackerService) {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var formView: View? = null
    private var currentForm: FormItem? = null
    private val forms = ArrayDeque<FormItem>()
    private var started = false
    private var sending = false

    private val listener =
        SharedPreferences.OnSharedPreferenceChangeListener { _, key -> onPref(key) }

    // ---------- вспомогательное ----------
    private fun dp(v: Int): Int = (v * svc.resources.displayMetrics.density).toInt()
    private fun sw(): Int = svc.resources.displayMetrics.widthPixels

    private fun toast(m: String) = Toast.makeText(svc, m, Toast.LENGTH_SHORT).show()

    private fun params(w: Int, h: Int): WindowManager.LayoutParams {
        val p = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        return p
    }

    private fun text(s: String, size: Float, color: Int): TextView {
        val t = TextView(svc)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        return t
    }

    private fun bigBtn(s: String, primary: Boolean, onClick: () -> Unit): TextView {
        val t = TextView(svc)
        t.text = s
        t.textSize = 15f
        t.setTypeface(t.typeface, Typeface.BOLD)
        t.setTextColor(Ui.TEXT)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(8), dp(12), dp(8), dp(12))
        val r = dp(12).toFloat()
        t.background = if (primary) Ui.button(r) else Ui.stateful(Ui.FIELD, Ui.BG, r)
        t.setOnClickListener { onClick() }
        return t
    }

    // ---------- жизненный цикл ----------
    fun start() {
        if (started) return
        started = true
        Store.prefs(svc).registerOnSharedPreferenceChangeListener(listener)
    }

    fun stop() {
        started = false
        Store.prefs(svc).unregisterOnSharedPreferenceChangeListener(listener)
        removeForm()
        forms.clear()
        currentForm = null
    }

    private fun onPref(key: String?) {
        if (key == "test_form") showForm("Test_Admin", "/jail 60 60 DM | T.Admin", true)
    }

    // ---------- окно формы ----------
    fun showForm(nick: String, command: String, test: Boolean) {
        val item = FormItem(nick, command, test)
        if (currentForm == item || forms.contains(item)) return
        forms.addLast(item)
        if (formView == null) showNextForm()
    }

    private fun showNextForm() {
        removeForm()
        val item = forms.removeFirstOrNull()
        if (item == null) {
            currentForm = null
            return
        }
        currentForm = item

        val w = min(dp(340), sw() - dp(24))
        val box = LinearLayout(svc)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(12), dp(12), dp(12))
        box.background = Ui.rounded(Ui.PANEL, dp(16).toFloat(), Ui.BURGUNDY_LIGHT, dp(2))

        val title = text("Форма от ${item.nick}" + (if (item.test) " (тест)" else ""), 15f, Ui.TEXT)
        title.setTypeface(title.typeface, Typeface.BOLD)
        box.addView(title)
        if (forms.isNotEmpty()) box.addView(text("Ещё в очереди: ${forms.size}", 12f, Ui.MUTED))

        val cmd = text(item.command, 16f, Ui.TEXT)
        cmd.typeface = Typeface.MONOSPACE
        cmd.background = Ui.rounded(Ui.FIELD, dp(10).toFloat())
        cmd.setPadding(dp(10), dp(10), dp(10), dp(10))
        val cmdLp = LinearLayout.LayoutParams(MATCH, WRAP)
        cmdLp.setMargins(0, dp(8), 0, dp(10))
        box.addView(cmd, cmdLp)

        val row = LinearLayout(svc)
        row.orientation = LinearLayout.HORIZONTAL
        val giveLp = LinearLayout.LayoutParams(0, WRAP, 1f)
        giveLp.setMargins(0, 0, dp(6), 0)
        row.addView(bigBtn("Выдать", true) { onGive(item) }, giveLp)
        row.addView(bigBtn("Отказать", false) { onDeny(item) }, LinearLayout.LayoutParams(0, WRAP, 1f))
        box.addView(row)

        val p = params(w, WRAP)
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.y = dp(36)
        try {
            wm.addView(box, p)
            formView = box
        } catch (e: Exception) {
            currentForm = null
            Store.addLog(svc, "Окно формы не показано: ${e.message}")
        }
    }

    private fun removeForm() {
        val f = formView
        if (f != null) {
            try {
                wm.removeView(f)
            } catch (e: Exception) {
            }
        }
        formView = null
    }

    // «Выдать»: команда уходит прямо в чат игры. Если поле чата не найдено, окно остаётся, можно повторить.
    private fun onGive(item: FormItem) {
        if (sending) return
        if (item.test) {
            toast("Тест: в игре команда ушла бы в чат")
            currentForm = null
            showNextForm()
            return
        }
        sending = true
        svc.sendChat(item.command) { ok ->
            sending = false
            if (ok) {
                Store.recordCommand(svc, item.command)
                Store.addLog(svc, "Форма отправлена в чат: ${item.command} (от ${item.nick})")
                currentForm = null
                showNextForm()
            } else {
                Store.addLog(svc, "Форма не отправлена, поле чата не найдено: ${item.command}")
                toast("Не нашёл поле чата в игре. Открой чат и нажми «Выдать» ещё раз.")
            }
        }
    }

    private fun onDeny(item: FormItem) {
        Store.addLog(svc, "Отказано: ${item.command} (от ${item.nick})")
        currentForm = null
        showNextForm()
    }
}
