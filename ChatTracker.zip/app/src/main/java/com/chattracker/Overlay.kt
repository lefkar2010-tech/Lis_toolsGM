package com.chattracker

import android.content.Context
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.min

data class FormItem(val nick: String, val command: String)

// Плавающий кружок, мини-панель репортов и окно формы поверх игры
class OverlayManager(private val svc: TrackerService) {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var bubble: TextView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private var panelList: LinearLayout? = null
    private var panelTitle: TextView? = null
    private var formView: View? = null
    private var currentForm: FormItem? = null
    private val forms = ArrayDeque<FormItem>()
    private var gameFg = true
    private var started = false

    private val listener =
        SharedPreferences.OnSharedPreferenceChangeListener { _, key -> onPref(key) }

    // ---------- вспомогательное ----------
    private fun dp(v: Int): Int = (v * svc.resources.displayMetrics.density).toInt()
    private fun sw(): Int = svc.resources.displayMetrics.widthPixels
    private fun sh(): Int = svc.resources.displayMetrics.heightPixels

    private fun toast(m: String) = Toast.makeText(svc, m, Toast.LENGTH_SHORT).show()

    private fun params(w: Int, h: Int): WindowManager.LayoutParams {
        val p = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        return p
    }

    private fun text(s: String, size: Float, color: Int): TextView {
        val t = TextView(svc)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        return t
    }

    private fun chip(s: String, onClick: () -> Unit): TextView {
        val t = TextView(svc)
        t.text = s
        t.textSize = 14f
        t.setTextColor(Ui.TEXT)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(11), dp(7), dp(11), dp(7))
        t.background = Ui.button(dp(9).toFloat())
        t.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.setMargins(dp(6), 0, 0, 0)
        t.layoutParams = lp
        return t
    }

    private fun bigBtn(s: String, primary: Boolean, onClick: () -> Unit): TextView {
        val t = TextView(svc)
        t.text = s
        t.textSize = 15f
        t.setTypeface(t.typeface, Typeface.BOLD)
        t.setTextColor(Ui.TEXT)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(8), dp(12), dp(8), dp(12))
        val r = dp(12).toFloat()
        t.background = if (primary) Ui.button(r) else Ui.stateful(Ui.FIELD, Ui.BG, r)
        t.setOnClickListener { onClick() }
        return t
    }

    // ---------- жизненный цикл ----------
    fun start() {
        if (started) return
        started = true
        Store.prefs(svc).registerOnSharedPreferenceChangeListener(listener)
        applyBubble()
    }

    fun stop() {
        started = false
        Store.prefs(svc).unregisterOnSharedPreferenceChangeListener(listener)
        removePanel()
        removeBubble()
        removeForm()
        forms.clear()
        currentForm = null
    }

    fun setGameForeground(v: Boolean) {
        if (gameFg == v) return
        gameFg = v
        applyBubble()
    }

    private fun applyBubble() {
        if (Store.overlayOn(svc) && gameFg) {
            showBubble()
        } else {
            removePanel()
            removeBubble()
        }
    }

    private fun onPref(key: String?) {
        when (key) {
            "overlay" -> applyBubble()
            "pkg" -> svc.updateOverlayVisibility()
            "reports" -> {
                updateBadge()
                renderPanel()
            }
            "test_form" -> showForm("Test_Admin", "/jail 60 60 DM | T.Admin")
        }
    }

    // ---------- кружок ----------
    private fun showBubble() {
        if (bubble != null) {
            updateBadge()
            return
        }
        val size = dp(52)
        val t = TextView(svc)
        t.gravity = Gravity.CENTER
        t.setTextColor(Ui.TEXT)
        t.textSize = 16f
        t.setTypeface(t.typeface, Typeface.BOLD)
        t.background = Ui.oval(Ui.BURGUNDY, Ui.BURGUNDY_LIGHT, dp(2))
        t.alpha = 0.92f

        val p = params(size, size)
        val saved = Store.prefs(svc)
        p.x = saved.getInt("ov_x", sw() - size).coerceIn(0, maxOf(0, sw() - size))
        p.y = saved.getInt("ov_y", sh() / 3).coerceIn(0, maxOf(0, sh() - size))
        t.setOnTouchListener(Drag())
        try {
            wm.addView(t, p)
            bubble = t
            bubbleLp = p
            updateBadge()
        } catch (e: Exception) {
            Store.addLog(svc, "Кружок не показан: ${e.message}")
        }
    }

    private fun removeBubble() {
        val b = bubble
        if (b != null) {
            try {
                wm.removeView(b)
            } catch (e: Exception) {
            }
        }
        bubble = null
        bubbleLp = null
    }

    private fun updateBadge() {
        val n = Store.getReports(svc).size
        bubble?.text = if (n > 0) n.toString() else "Р"
    }

    private inner class Drag : View.OnTouchListener {
        private var sx = 0
        private var sy = 0
        private var tx = 0f
        private var ty = 0f
        private var moved = false

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            val p = bubbleLp ?: return false
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = p.x
                    sy = p.y
                    tx = e.rawX
                    ty = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt()
                    val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) {
                        if (!moved && panel != null) removePanel()
                        moved = true
                    }
                    if (moved) {
                        p.x = sx + dx
                        p.y = sy + dy
                        try {
                            wm.updateViewLayout(v, p)
                        } catch (ex: Exception) {
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) snapAndSave(v, p) else togglePanel()
                }
            }
            return true
        }
    }

    private fun snapAndSave(v: View, p: WindowManager.LayoutParams) {
        val size = p.width
        p.x = if (p.x + size / 2 < sw() / 2) 0 else sw() - size
        p.y = p.y.coerceIn(0, maxOf(0, sh() - size))
        try {
            wm.updateViewLayout(v, p)
        } catch (e: Exception) {
        }
        Store.prefs(svc).edit().putInt("ov_x", p.x).putInt("ov_y", p.y).apply()
    }

    // ---------- панель репортов ----------
    private fun togglePanel() {
        if (panel != null) removePanel() else showPanel()
    }

    private fun showPanel() {
        val bp = bubbleLp ?: return
        val w = min(dp(300), sw() - dp(70))
        val maxH = min(dp(300), sh() - dp(80))

        val root = LinearLayout(svc)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(10), dp(8), dp(10), dp(10))
        root.background = Ui.rounded(Ui.PANEL, dp(14).toFloat(), Ui.BURGUNDY, dp(1))

        val head = LinearLayout(svc)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = text("Репорты", 15f, Ui.TEXT)
        title.setTypeface(title.typeface, Typeface.BOLD)
        head.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(chip("✕") { removePanel() })
        val headLp = LinearLayout.LayoutParams(MATCH, WRAP)
        headLp.setMargins(0, 0, 0, dp(6))
        root.addView(head, headLp)

        val sc = object : ScrollView(svc) {
            override fun onMeasure(wSpec: Int, hSpec: Int) {
                super.onMeasure(wSpec, View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST))
            }
        }
        val list = LinearLayout(svc)
        list.orientation = LinearLayout.VERTICAL
        sc.addView(list)
        root.addView(sc, LinearLayout.LayoutParams(MATCH, WRAP))

        val p = params(w, WRAP)
        val onLeft = bp.x + bp.width / 2 < sw() / 2
        p.x = (if (onLeft) bp.x + bp.width + dp(6) else bp.x - w - dp(6)).coerceIn(0, maxOf(0, sw() - w))
        p.y = bp.y.coerceIn(0, maxOf(0, sh() - dp(220)))
        try {
            wm.addView(root, p)
            panel = root
            panelList = list
            panelTitle = title
            renderPanel()
        } catch (e: Exception) {
            Store.addLog(svc, "Панель не показана: ${e.message}")
        }
    }

    private fun removePanel() {
        val pv = panel
        if (pv != null) {
            try {
                wm.removeView(pv)
            } catch (e: Exception) {
            }
        }
        panel = null
        panelList = null
        panelTitle = null
    }

    private fun renderPanel() {
        val list = panelList ?: return
        val rs = Store.getReports(svc)
        val pending = rs.size
        panelTitle?.text = "Репорты ($pending)"
        list.removeAllViews()
        if (rs.isEmpty()) {
            list.addView(text("Репортов пока нет", 13f, Ui.MUTED))
            return
        }
        for (r in rs.take(30)) {
            val row = LinearLayout(svc)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(8), dp(6), dp(6), dp(6))
            row.background = Ui.rounded(Ui.CARD, dp(10).toFloat())

            val msg = if (r.msg.isNotEmpty()) r.msg else "(без текста)"
            val tv = text("${r.time}  ${r.nick}[${r.pid}]\n$msg · очередь ${r.queue}", 13f, Ui.TEXT)
            row.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
            row.addView(chip("ID") {
                Clip.copy(svc, r.pid)
                toast("ID ${r.pid} скопирован")
            })
            row.addView(chip("✓") { Store.deleteReport(svc, r.uid) })

            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.setMargins(0, 0, 0, dp(5))
            list.addView(row, lp)
        }
    }

    // ---------- окно формы ----------
    fun showForm(nick: String, command: String) {
        val item = FormItem(nick, command)
        if (currentForm == item || forms.contains(item)) return
        forms.addLast(item)
        if (formView == null) showNextForm()
    }

    private fun showNextForm() {
        removeForm()
        val item = forms.removeFirstOrNull()
        if (item == null) {
            currentForm = null
            return
        }
        currentForm = item

        val w = min(dp(340), sw() - dp(24))
        val box = LinearLayout(svc)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(12), dp(12), dp(12))
        box.background = Ui.rounded(Ui.PANEL, dp(16).toFloat(), Ui.BURGUNDY_LIGHT, dp(2))

        val title = text("Форма от ${item.nick}", 15f, Ui.TEXT)
        title.setTypeface(title.typeface, Typeface.BOLD)
        box.addView(title)
        if (forms.isNotEmpty()) box.addView(text("Ещё в очереди: ${forms.size}", 12f, Ui.MUTED))

        val cmd = text(item.command, 16f, Ui.TEXT)
        cmd.typeface = Typeface.MONOSPACE
        cmd.background = Ui.rounded(Ui.FIELD, dp(10).toFloat())
        cmd.setPadding(dp(10), dp(10), dp(10), dp(10))
        val cmdLp = LinearLayout.LayoutParams(MATCH, WRAP)
        cmdLp.setMargins(0, dp(8), 0, dp(10))
        box.addView(cmd, cmdLp)

        val row = LinearLayout(svc)
        row.orientation = LinearLayout.HORIZONTAL
        val giveLp = LinearLayout.LayoutParams(0, WRAP, 1f)
        giveLp.setMargins(0, 0, dp(6), 0)
        row.addView(bigBtn("Выдать", true) { onGive(item) }, giveLp)
        row.addView(bigBtn("Отказать", false) { onDeny(item) }, LinearLayout.LayoutParams(0, WRAP, 1f))
        box.addView(row)

        val p = params(w, WRAP)
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.y = dp(36)
        try {
            wm.addView(box, p)
            formView = box
        } catch (e: Exception) {
            currentForm = null
            Store.addLog(svc, "Окно формы не показано: ${e.message}")
        }
    }

    private fun removeForm() {
        val f = formView
        if (f != null) {
            try {
                wm.removeView(f)
            } catch (e: Exception) {
            }
        }
        formView = null
    }

    private fun onGive(item: FormItem) {
        val ok = svc.insertIntoChat(item.command)
        Store.recordCommand(svc, item.command)
        if (ok) {
            Store.addLog(svc, "Выдано: ${item.command} (от ${item.nick})")
            toast("Форма вставлена в чат")
        } else {
            Clip.copy(svc, item.command)
            Store.addLog(svc, "Выдано, чат не в фокусе, скопировано: ${item.command} (от ${item.nick})")
            toast("Чат не в фокусе: форма скопирована")
        }
        currentForm = null
        showNextForm()
    }

    private fun onDeny(item: FormItem) {
        Store.addLog(svc, "Отказано: ${item.command} (от ${item.nick})")
        currentForm = null
        showNextForm()
    }
}
