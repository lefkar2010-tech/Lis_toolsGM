package com.chattracker

import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable

object Ui {
    val BG = 0xFF0F0F13.toInt()
    val CARD = 0xFF1B1B21.toInt()
    val FIELD = 0xFF2A2A32.toInt()
    val BURGUNDY = 0xFF7A1F2E.toInt()
    val BURGUNDY_DARK = 0xFF55141F.toInt()
    val BURGUNDY_LIGHT = 0xFFA32A3E.toInt()
    val TEXT = 0xFFECECEF.toInt()
    val MUTED = 0xFF9A9AA3.toInt()
    val PANEL = 0xF2161619.toInt()

    fun rounded(color: Int, radius: Float, stroke: Int = 0, strokePx: Int = 0): GradientDrawable {
        val d = GradientDrawable()
        d.shape = GradientDrawable.RECTANGLE
        d.cornerRadius = radius
        d.setColor(color)
        if (strokePx > 0) d.setStroke(strokePx, stroke)
        return d
    }

    fun oval(color: Int, stroke: Int, strokePx: Int): GradientDrawable {
        val d = GradientDrawable()
        d.shape = GradientDrawable.OVAL
        d.setColor(color)
        d.setStroke(strokePx, stroke)
        return d
    }

    fun stateful(normal: Int, pressed: Int, radius: Float): StateListDrawable {
        val s = StateListDrawable()
        s.addState(intArrayOf(android.R.attr.state_pressed), rounded(pressed, radius))
        s.addState(intArrayOf(), rounded(normal, radius))
        return s
    }

    fun button(radius: Float): StateListDrawable = stateful(BURGUNDY, BURGUNDY_DARK, radius)
}
